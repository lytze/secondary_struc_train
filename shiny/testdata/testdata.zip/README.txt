__set0__ is the UCI dataset originally prepared for this assignment. The set has been divided into `set0_train.txt` and `set0_test.txt`. Using these sets for a test model training is suggested.

__set1__ is a set prepared from several entries of PDB. This set has a `set1_seq_only.txt` set which has sequence lines only, which can be used for testing a trained model.
